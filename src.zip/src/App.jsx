import ColdCallCRM from './ColdCallCRM'

function App() {
  return <ColdCallCRM />
}

export default App
